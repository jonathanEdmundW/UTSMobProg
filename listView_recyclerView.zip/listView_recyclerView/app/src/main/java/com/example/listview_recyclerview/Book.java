package com.example.listview_recyclerview;

import java.io.Serializable;

public class Book implements Serializable {

    String title;
    String author;
    String desc;
    double price;
    int image;
}
